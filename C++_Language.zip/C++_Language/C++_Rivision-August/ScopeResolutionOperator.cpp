// Scope Resolution Operator
#include <iostream>
using namespace std;
void main()
{
}