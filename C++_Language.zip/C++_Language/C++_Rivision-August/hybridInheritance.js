// Hybrid Inheritance
