// Print a String in a c++ program
#include<iostream>
using namespace std;
int main()
{
    char name[23];
    cout << "Enter Your NAme : ";
    cin.getline(name, 23);
    
}
