// printing bool DT
#include <iostream>
using namespace std;
int main()
{
    bool choice = 0;
    cout << "\nChoice : " << choice << endl;
    bool choice1 = true; // can use 0 or 1
    {
        cout << "Choice : " << choice1 << endl;
        cout << "Choice : " << choice1 << endl;
    }
}