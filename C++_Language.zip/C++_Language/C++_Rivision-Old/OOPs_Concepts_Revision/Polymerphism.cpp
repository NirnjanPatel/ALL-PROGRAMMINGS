/* Polymerphism - 

1. Compile_Time_Polymerphsm -
*1.Function_Overloading / Method_Overloading - 
*2. Operator_Overloading

2. Run_Time_Polymerphsm / Dynamic_Binding / Late_Binding
*1. Virtual Function  
*/
#include <iostream>
using namespace std;
int main()
{

    return 0;
}