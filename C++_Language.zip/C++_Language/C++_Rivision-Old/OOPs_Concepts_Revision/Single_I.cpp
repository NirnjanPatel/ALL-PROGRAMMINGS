// Single_Inheritance
#include <iostream>
using namespace std;
class Parent
{
    public:
    cout<<"Parent class called...!!" >> endl;
};
class Child : public Parent
{

};
int main()
{

    return 0;
}