#include<iostream>
using namespace std;
int main()
{
    if(012==10) // Here 012 is an octl number
    {
        cout << "S1" << endl;
    }
    else 
    {
        cout << "S2" << endl;   
    }
    return 0;
}