#include<iostream>
using namespace std;
int main()
{
    if(0/5)
    {
        cout << "S1" << endl;
    }
        if(0)
    {
        cout << "S2" << endl;
    }
        if(5)
    {
        cout << "S3" << endl;
    }
    if ('0')
    {
        cout << "S4" << endl;
    }
    if ('n')
    {
        cout << "S5" << endl;
    }
    return 0;
}
