// Shallow Copy Constructor
#include <iostream>
using namespace std;

int main()
{
}