        obj.km = km + d2.km;
