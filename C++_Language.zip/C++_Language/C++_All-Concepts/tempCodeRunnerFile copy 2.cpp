    Demo d1, d2, d3, d4, d5;
