// Practise of upper to lower
#include <iostream>
#include <string.h>
using namespace std;
char getLowerToUpper(char name[])
{
    int length;
    length = strlen(name);
}
int main()
{
    char name[50];
    getLowerToUpper(name);
}
