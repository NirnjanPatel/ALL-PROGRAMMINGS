//oops

class Demo
{
 demoData()
 {
  console.log("Welcome to ES6 oops");    
 }        
}

var obj = new Demo();
obj.demoData();