/*
spread operator (...)
The main difference between rest and spread is that the rest operator puts the rest of some 
specific user-supplied values into a JavaScript array. But the spread syntax expands iterables 
into individual elements.
*/

var empDetails={"eno":1001,"enm":"John","esal":10000.67};

/*empDetails.edes="trainer";*/
// empDetails.edob=15;

empDetails={...empDetails,"edes":"trainer","edob":15};

console.log("Employee Details :");
console.log(empDetails);