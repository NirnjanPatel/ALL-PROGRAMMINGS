var a;
a=100;
export default a;

export var b=200;

export function demo()
{
 console.log("Module m2 , demo function invoked");    
}

export function demo1()
{
 console.log("Module m2 , demo1 function invoked");    
}