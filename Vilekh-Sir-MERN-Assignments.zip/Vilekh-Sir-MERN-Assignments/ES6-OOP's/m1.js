var a;
a=100;
export default a;

export var b=200;