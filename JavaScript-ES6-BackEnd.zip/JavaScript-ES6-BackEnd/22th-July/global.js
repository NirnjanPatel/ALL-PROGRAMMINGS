// global parameters : 
import * as __dirname from "fs";
console.log("current working directory :", __dirname);

console.log("current working file :", __filename);

