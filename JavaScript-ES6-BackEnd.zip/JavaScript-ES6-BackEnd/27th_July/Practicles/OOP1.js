class Demo {
    demoData() {
        console.log("demoData function called---!!!");
        var a = 34;
    }
}
var obj = new Demo();

obj.demoData();

// console.log(obj.demoData());
console.log(obj.a);
// console.log(obj.demoData().a);
// var a = obj.a;
// console.log(a);