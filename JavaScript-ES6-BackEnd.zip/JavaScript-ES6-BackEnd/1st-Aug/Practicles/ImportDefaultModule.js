// Import Default Module
// import { a } from './ModuleExportDefault.js';
// console.log("a = " + a +);

import a from './ModuleExportDefault.js';
console.log("A = " + a);