var z = 34;
console.log(z);
console.log("Hello This is Nodejs Tutorial");
console.warn("Hello This is Nodejs Tutorial");
console.error("Hello This is Nodejs Tutorial");