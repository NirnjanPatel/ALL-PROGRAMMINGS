// Global npm modules
// package.json = stores dependences details
// No effects on deleting package.json
// global module =
// local module = which present in same folder, only works for that folder

// nodemon  = is a global module
// nodemon is a tool that helps develop Node.js based applications by automatically restarting the node application when file changes in the directory are detected.
// installation = npm install -g nodemon -> -g = global
const validator = require("validator");
const res = validator.isEmail("Nirnjn.n.df@gmail.com");
console.log(res);
console.log(res);
console.log(res);
console.log(res);
