// moduleFile

// const add = require('./createOwnModule');  // Module name
// const sub = require('./createOwnModule');  // Module name

// Calling indivisually

// console.log(add(5, 5));
// console.log(sub(5, 5));
// console.log(name);
// console.log("Finished");

// calling using ann object (variable) 

const { add, sub, mult, name } = require("./ createOwnModule");

// getting the value of all function at a time
console.log(add(6, 45));
console.log(sub(6, 45));
console.log(mult(6, 45));


